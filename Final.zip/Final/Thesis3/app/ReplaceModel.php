<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReplaceModel extends Model
{
    //
    protected $table = 'replacement';
    protected $primaryKey = 'replace_id';
}
