<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Helper;
class PageControl extends Controller
{

public function index(){
	return view ('Admin.index');
}
public function inventory(){
	return view ('Admin.inventory');
}
public function purchase(){
	return view ('Admin.purchases');
}
public function replace(){
	return view ('Admin.replacement');
}
public function settings(){
	return view ('Admin.settings');
}
public function register(){
	return view ('Admin.register');
}
public function addPurchase(){
	return view ('Admin.addpurchase');
}
public function addreplacement(){
	return view ('Admin.addreplacement');
}
public function editaccount(){
	return view ('Admin.editaccount');
}
public function walkin(){

        $currentUser = Helper::staticInfo();
        $displaySales = DB::select('SELECT o.order_id, o.or_number, CONCAT(c.first_name, " ", c.last_name) AS name, o.order_type, s.cost, s.created_at FROM
                    clients c INNER JOIN orders o INNER JOIN sales s ON s.order_id = o.order_id AND o.client_id = c.client_id');

        $orderDetails = DB::select('SELECT o.order_id, inventory_item, i.cost from order_details o INNER JOIN inventory i ON o.inventory_id = i.inventory_id;');

        return view('Admin.walkinclient', compact('currentUser', 'displaySales', 'orderDetails'));

}
public function createaccount(Request $request){
	$currentUser = Helper::staticInfo();
	$posts = $users = DB::table('users')
            ->select('user_id',\DB::raw('CONCAT(first_name," ", last_name) AS fullname'),'username','password','last_login')->get();
	return view ('Admin.settings-createaccount',compact('currentUser','posts'));
}
}
